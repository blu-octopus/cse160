# Assignment 5a: Exploring a High-Level Graphics Library

<!-- have a title across the table saying assets -->
<!-- table with categories: assets used, asset author, asset link -->

## Assets
| Asset Name | Author | Link |
|------------|--------|------|
| samurai capy| [memoov](https://sketchfab.com/movartD) | [https://sketchfab.com/3d-models/samurai-capybara](https://sketchfab.com/3d-models/samurai-capybara-6adf1904b9e744ff9381583336377080) |
